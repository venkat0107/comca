
## Content Migration of AEM Instances

The purpose of this module is to create an automation script for AEM instances:
- AEM Author
- AEM Publisher
## Author

<a href="mailto:vishnuvardhan_krishnan@comcast.com">Vishnuvardhan Krishnan</a>

@Vishnu