#!/usr/bin/env bash

fly --target ci login --concourse-url https://ci.comcast.net --team-name marketingtechnology --open-browser
fly -t ci set-pipeline -c pipeline.yml -p dam-content-migration