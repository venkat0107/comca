#!/bin/sh

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID}"
export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY}"
export AWS_DEFAULT_REGION="${REGION}"

AEM_DEVICE_NAME="/dev/sdh"
TODAY=$(date +'%d-%m-%Y-%H:%M')

SRC_TAG=$(cat instance/src_tag)
ENVIRONMENT=$(cat instance/env_name)

SRC_PUBLISH_INSTANCE_ID=$(cat instance/src_publish_instance_id)
echo "SOURCE AEM PUBLISH INSTANCE ID is ${SRC_PUBLISH_INSTANCE_ID}"

### Fetch Volume ID of the AEM instances
SRC_PUBLISH_VOL_ID=$(aws ec2 describe-volumes --filters Name=attachment.instance-id,Values="${SRC_PUBLISH_INSTANCE_ID}" Name=attachment.device,Values="${AEM_DEVICE_NAME}" --query Volumes[].VolumeId --output text)
echo "SOURCE AEM PUBLISH VOLUME is ${SRC_PUBLISH_VOL_ID}"
echo "${SRC_PUBLISH_VOL_ID}" > volume/src_publish_volume_id

### Use a description for Snapshot
PUBLISH_SNAPSHOT_DESC="aem-publish-${AEM_DEVICE_NAME}-${TODAY}"

### Execute Snapshot
PUBLISH_SNAPSHOT_ID=$(aws ec2 create-snapshot --output=text --description "${PUBLISH_SNAPSHOT_DESC}" --volume-id "${SRC_PUBLISH_VOL_ID}" --query SnapshotId)

### Add tags to the snapshot
aws ec2 create-tags --resource "${PUBLISH_SNAPSHOT_ID}" --tags Key=CreatedByFor,Value=BackupForAEMContentMigration Key=Application,Value=AEM Key=Name,Value=aem-"${ENVIRONMENT}"-publish"${SRC_TAG}" Key=Owner,Value=Martech

### Wait for Snapshot Completion
PUBLISH_SNAPSHOTPROGRESS=$(aws ec2 describe-snapshots --snapshot-ids "${PUBLISH_SNAPSHOT_ID}" --query "Snapshots[*].Progress" --output text)

echo "CREATING SNAPSHOT FOR SOURCE AEM PUBLISH..."
while [ "${PUBLISH_SNAPSHOTPROGRESS}" != "100%" ]
do
  sleep 30
  echo "PROGRESS is ${PUBLISH_SNAPSHOTPROGRESS}"
  PUBLISH_SNAPSHOTPROGRESS=$(aws ec2 describe-snapshots --snapshot-ids "${PUBLISH_SNAPSHOT_ID}" --query "Snapshots[*].Progress" --output text)
done
echo "SOURCE AEM PUBLISH SNAPSHOT is ${PUBLISH_SNAPSHOT_ID}"
sleep 30

echo "${PUBLISH_SNAPSHOT_ID}" > snapshot/publish_snapshot_id