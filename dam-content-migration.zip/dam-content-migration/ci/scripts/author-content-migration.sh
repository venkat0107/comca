#!/usr/bin/env bash

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

SSH_TUNNEL_PORT="5555"

eval "$(ssh-agent -s)"
chmod 400 key/keypair

DEST_AUTHOR_IP=$(cat instance/dest_author_private_ip)
echo "DESTINATION AEM AUTHOR IP is ${DEST_AUTHOR_IP}"

DEST_AUTHOR_INSTANCE_ID=$(cat instance/dest_author_instance_id)
echo "DESTINATION AEM INSTANCE ID is ${DEST_AUTHOR_INSTANCE_ID}"

cd certs
ssh-add atb_service_user
ssh-add -l
ssh -o ProxyCommand='ssh -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SSH_TUNNEL_PORT":"$DEST_AUTHOR_IP":22 &
cd ..
sleep 5
### Opening tunnel to Destination Author
printf "\nTUNNEL OPEN TO DESTINATION AUTHOR at %s\n" "${DEST_AUTHOR_IP}"
echo "INITIATING CONTENT MIGRATION PROCESS ON DESTINATION AUTHOR INSTANCE ${DEST_AUTHOR_INSTANCE_ID}..."
### Executing migration script on the destination author
ssh -q -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT} ec2-user@localhost "sudo /apps/adobe/aem6.4/crx2oak-content-migration.sh \&"
sleep 5
echo "MIGRATION COMPLETED ON DESTINATION PUBLISH INSTANCE ${DEST_AUTHOR_IP}"
kill %1

sleep 5