#!/usr/bin/env bash

julien

eval "$(ssh-agent -s)"

echo "$ATB_PRIVATE_KEY" > atb_service_user
chmod 600  atb_service_user
chmod 600  atb_service_user-cert.pub
mv atb_service_user-cert.pub certs/atb_service_user-cert.pub
mv atb_service_user certs/atb_service_user