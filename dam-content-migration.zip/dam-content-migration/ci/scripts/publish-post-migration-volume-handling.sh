#!/bin/sh

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID}"
export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY}"
export AWS_DEFAULT_REGION="${REGION}"

SRC_PUBLISH_INSTANCE_ID=$(cat instance/src_publish_instance_id)
DEST_PUBLISH_INSTANCE_ID=$(cat instance/dest_publish_instance_id)
SRC_PUBLISH_VOLUME_ID=$(cat volume/src_publish_volume_id)

### Detach volume from the Destination AEM publish instance
echo "DETACHING VOLUME ${SRC_PUBLISH_VOLUME_ID} FROM DESTINATION PUBLISH INSTANCE ${DEST_PUBLISH_INSTANCE_ID}..."
aws ec2 detach-volume --volume-id "${SRC_PUBLISH_VOLUME_ID}" --instance-id "${DEST_PUBLISH_INSTANCE_ID}"
sleep 30s
echo "VOLUME DETACHED"
echo "---------------"
### Attach volume to the Source AEM publish instance
echo "ATTACHING VOLUME ${SRC_PUBLISH_VOLUME_ID} TO SOURCE PUBLISH INSTANCE ${SRC_PUBLISH_INSTANCE_ID}..."
aws ec2 attach-volume --volume-id "${SRC_PUBLISH_VOLUME_ID}" --instance-id "${SRC_PUBLISH_INSTANCE_ID}" --device /dev/sdh
sleep 30s
echo "VOLUME ATTACHED"