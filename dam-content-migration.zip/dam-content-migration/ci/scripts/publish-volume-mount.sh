#!/usr/bin/env bash

SSH_TUNNEL_PORT="6661"

eval "$(ssh-agent -s)"
chmod 400 key/keypair

SRC_PUBLISH_INSTANCE_ID=$(cat instance/src_publish_instance_id)
SRC_PUBLISH_IP=$(cat instance/src_publish_private_ip)

cd certs
ssh-add atb_service_user
ssh-add -l
ssh -o ProxyCommand='ssh -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SSH_TUNNEL_PORT":"$SRC_PUBLISH_IP":22 &
cd ..
sleep 5
### Opening tunnel to Source AEM Publish
printf "\nTUNNEL OPEN TO DESTINATION PUBLISH at %s\n" "${SRC_PUBLISH_IP}"
### Mounting volume to the source publish instance
echo "MOUNTING VOLUME /dev/nvme1n1 BACK TO SOURCE PUBLISH INSTANCE ${SRC_PUBLISH_INSTANCE_ID}..."
ssh -q -o IPQoS=throughput -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT} ec2-user@localhost 'sudo mount /dev/nvme1n1 /apps/adobe && df -hT /adobe'
sleep 5
printf "VOLUME MOUNTED\n\n"
### Starting AEM Publish instance
ssh -q -o IPQoS=throughput -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT} ec2-user@localhost 'sudo /etc/init.d/cq64-publish start'
sleep 5
printf "SOURCE AEM PUBLISH INSTANCE STARTED\n\n"
### Start Filebeat service
ssh -q -o IPQoS=throughput -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT} ec2-user@localhost 'sudo service filebeat start'
sleep 5
printf "FILEBEAT SERVICE STARTED"
kill %1