#!/usr/bin/env bash

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

SSH_TUNNEL_PORT="5551"

eval "$(ssh-agent -s)"
chmod 400 key/keypair

DEST_PUBLISH_IP=$(cat instance/dest_publish_private_ip)
echo "DESTINATION AEM PUBLISH IP is ${DEST_PUBLISH_IP}"

DEST_PUBLISH_INSTANCE_ID=$(cat instance/dest_publish_instance_id)
echo "DESTINATION AEM INSTANCE ID is ${DEST_PUBLISH_INSTANCE_ID}"

cd certs
ssh-add atb_service_user
ssh-add -l
ssh -o ProxyCommand='ssh -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SSH_TUNNEL_PORT":"$DEST_PUBLISH_IP":22 &
cd ..
sleep 5
### Opening tunnel to Destination Publish
printf "\nTUNNEL OPEN TO DESTINATION PUBLISH at %s\n" "${DEST_PUBLISH_IP}"
echo "INITIATING CONTENT MIGRATION PROCESS ON DESTINATION PUBLISH INSTANCE ${DEST_PUBLISH_INSTANCE_ID}..."
### Executing migration script on the destination publish
ssh -q -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT} ec2-user@localhost "sudo /apps/adobe/aem6.4/crx2oak-content-migration.sh \&"
sleep 5
echo "MIGRATION COMPLETED ON DESTINATION PUBLISH INSTANCE ${DEST_PUBLISH_IP}"
kill %1

sleep 5