#!/usr/bin/env bash

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

SSH_TUNNEL_PORT_1="4441"
SSH_TUNNEL_PORT_2="4451"

eval "$(ssh-agent -s)"
chmod 400 key/keypair

SRC_PUBLISH_INSTANCE_ID=$(cat instance/src_publish_instance_id)
SRC_PUBLISH_IP=$(cat instance/src_publish_private_ip)
echo "SOURCE AEM PUBLISH IP is ${SRC_PUBLISH_IP}"

SRC_PUBLISH_VOL_ID=$(cat volume/src_publish_volume_id)
echo "SOURCE AEM PUBLISH VOLUME is ${SRC_PUBLISH_VOL_ID}"

DEST_PUBLISH_IP=$(cat instance/dest_publish_private_ip)

cd certs
ssh-add atb_service_user
ssh-add -l
ssh -o ProxyCommand='ssh -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SSH_TUNNEL_PORT_1":"$SRC_PUBLISH_IP":22 &
cd ..
sleep 5
### Opening tunnel to Source Publish
printf "\nTUNNEL OPEN TO SOURCE PUBLISH at %s\n" "${SRC_PUBLISH_IP}"
echo "UNMOUNTING AEM VOLUME ${SRC_PUBLISH_VOL_ID}..."
### Unmounting the AEM volume from source AEM Publish instance
ssh -q -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT_1} ec2-user@localhost "sudo umount /dev/nvme1n1"
sleep 5
echo "AEM VOLUME ${SRC_PUBLISH_VOL_ID} (/dev/nvme1n1) UNMOUNTED FROM SOURCE AEM PUBLISH INSTANCE ${SRC_PUBLISH_INSTANCE_ID}"
kill %1

cd certs
ssh -o ProxyCommand='ssh -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SSH_TUNNEL_PORT_2":"$DEST_PUBLISH_IP":22 &
cd ..
sleep 5
printf "\nTUNNEL OPEN TO DESTINATION PUBLISH at %s\n" "${DEST_PUBLISH_IP}"
### Download CRX2Oak content migration script from S3
printf "DOWNLOADING CONTENT MIGRATION SCRIPT FROM S3..."
ssh -q -o IPQoS=throughput -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT_2} ec2-user@localhost 'sudo aws s3 cp s3://'"dam-aem-files${ENV_SUFFIX}"'/crx2oak-content-migration.sh /apps/adobe/aem6.4/ && sudo chmod +x /apps/adobe/aem6.4/crx2oak-content-migration.sh'
kill %1