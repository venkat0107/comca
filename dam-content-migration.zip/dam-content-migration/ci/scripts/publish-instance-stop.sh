#!/bin/sh

SRC_SSH_TUNNEL_PORT="2221"
DEST_SSH_TUNNEL_PORT="3331"
PUBLISH_TUNNEL_PORT="9443"
AEM_PORT="8443"
AEM_PASSWORD=$(cat key/aempasswd)
CURL="curl -k -s -# -u admin:${AEM_PASSWORD}"

eval "$(ssh-agent -s)"
chmod 400 key/keypair

SRC_PUBLISH_IP=$(cat instance/src_publish_private_ip)
echo "SOURCE AEM PUBLISH IP is ${SRC_PUBLISH_IP}"

DEST_PUBLISH_IP=$(cat instance/dest_publish_private_ip)
echo "DESTINATION AEM PUBLISH IP is ${DEST_PUBLISH_IP}"

cd certs
ssh-add atb_service_user
ssh-add -l
ssh -o ProxyCommand='ssh -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SRC_SSH_TUNNEL_PORT":"$SRC_PUBLISH_IP":22 &
cd ..
sleep 5
### Opening tunnel to Source Publish
printf "\nTUNNEL OPEN TO SOURCE PUBLISH AT %s\n\n" "${SRC_PUBLISH_IP}"
### Stop AEM Publish instance
ssh -q -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SRC_SSH_TUNNEL_PORT} ec2-user@localhost 'sudo /etc/init.d/cq64-publish stop'
printf "SOURCE AEM PUBLISH INSTANCE STOPPED\n\n"
### Stop Filebeat service
ssh -q -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SRC_SSH_TUNNEL_PORT} ec2-user@localhost 'sudo service filebeat stop'
sleep 5
printf "FILEBEAT SERVICE STOPPED\n\n"
kill %1

cd certs
ssh -o ProxyCommand='ssh -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$PUBLISH_TUNNEL_PORT":"$DEST_PUBLISH_IP":"$AEM_PORT" &
cd ..
sleep 5
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=creatorAtom&NewURI=http://ns.adobe.com/creatorAtom/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=stMfs&NewURI=http://ns.adobe.com/xap/1.0/sType/ManifestItem#' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=ns3_1_&NewURI=http://ns.adobe.com/bwf/bext/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=ns4&NewURI=http://ns.adobe.com/riff/info/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=ns5&NewURI=http://ns.adobe.com/ixml/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=stLoc&NewURI=http://ns.adobe.com/xap/1.0/sType/DataLocation#' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=stVer&NewURI=http://ns.adobe.com/xap/1.0/sType/Version#' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=xmpNote&NewURI=http://ns.adobe.com/xmp/note/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egBarcL&NewURI=http://ns.esko-graphics.com/barcodelist/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egCadL&NewURI=http://ns.esko-graphics.com/cadlist/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egExtFL&NewURI=http://ns.esko-graphics.com/extfileslist/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egExtFL2&NewURI=http://ns.esko-graphics.com/extfileslist/2.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egFont&NewURI=http://ns.esko-graphics.com/fontinfo/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egFontL&NewURI=http://ns.esko-graphics.com/fontlist/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egGr&NewURI=http://ns.esko-graphics.com/grinfo/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egInkCov&NewURI=http://ns.esko-graphics.com/inkcov/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egInkCovL&NewURI=http://ns.esko-graphics.com/inkcovlist/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egInk&NewURI=http://ns.esko-graphics.com/inkinfo/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egJob&NewURI=http://ns.esko-graphics.com/jobinfo/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egLay&NewURI=http://ns.esko-graphics.com/layer/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egLayL&NewURI=http://ns.esko-graphics.com/laylist/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egPag&NewURI=http://ns.esko-graphics.com/pagerange/1.1/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egPagL&NewURI=http://ns.esko-graphics.com/pagerangelist/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egPDFNat&NewURI=http://ns.esko-graphics.com/pdfnatversion/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egPrF&NewURI=http://ns.esko-graphics.com/prodfile/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egSmartID&NewURI=http://ns.esko-graphics.com/smartid/1.0/' > /dev/null
$CURL "https://localhost:${PUBLISH_TUNNEL_PORT}/crx/explorer/ui/namespace_editor.jsp?Path=&Callback=reload" --data 'NewPrefix=egSrLayout&NewURI=http://ns.esko-graphics.com/srlayout/1.0/' > /dev/null
sleep 5
printf "NAMEPACES CREATED ON PUBLISH INSTANCE\n"
kill %1

cd certs
ssh -o ProxyCommand='ssh -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$DEST_SSH_TUNNEL_PORT":"$DEST_PUBLISH_IP":22 &
cd ..
sleep 5
### Opening tunnel to Destination Publish
printf "\nTUNNEL OPEN TO DESTINATION PUBLISH AT %s\n" "${DEST_PUBLISH_IP}"
### Stop AEM Publish instance
ssh -q -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${DEST_SSH_TUNNEL_PORT} ec2-user@localhost 'sudo /etc/init.d/cq64-publish stop'
sleep 5
printf "DESTINATION AEM PUBLISH INSTANCE STOPPED"
kill %1