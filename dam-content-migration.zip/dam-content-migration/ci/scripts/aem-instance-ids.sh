#!/bin/sh

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID}"
export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY}"
export AWS_DEFAULT_REGION="${REGION}"

ENVIRONMENT="nonprod"
[ -z "${ENV_SUFFIX}" ] && ENVIRONMENT="prod"
echo "ENVIRONMENT is ${ENVIRONMENT}"

### Read the source and destination tag
SRC_TAG=$(cat code/ci/scripts/_source_aem_tag."${ENVIRONMENT}")
DEST_TAG=$(cat code/ci/scripts/_destination_aem_tag."${ENVIRONMENT}")

echo "SOURCE AEM TAG is ${SRC_TAG}"
echo "DESTINATION AEM TAG is ${DEST_TAG}"
echo "ZONE ID is ${ZONE_ID}"
echo "SUFFIX is ${ENV_SUFFIX}"

### Uploading CRX2Oak Migration script to S3
printf "\nUPLOADING CRX2OAK CONTENT MIGRATION SCRIPT TO S3...\n"
aws s3 cp code/source/crx2oak-content-migration.sh s3://dam-aem-files"${ENV_SUFFIX}"/
printf "UPLOAD DONE\n\n"

### Queries route53 using the value of the tag and resolves the IP of the author instance
SRC_AUTHOR_IP=$(aws route53 list-resource-record-sets --hosted-zone-id "${ZONE_ID}" | jq -c -r '.ResourceRecordSets | map(select(.Name | contains ("aemauthor'"${ENV_SUFFIX}""${SRC_TAG}"'."))) | .[] .ResourceRecords | .[] .Value')
[ -z "${SRC_AUTHOR_IP}" ] && exit 1

SRC_PUBLISH_IP=$(aws route53 list-resource-record-sets --hosted-zone-id "${ZONE_ID}" | jq -c -r '.ResourceRecordSets | map(select(.Name | contains ("aempublish-1'"${ENV_SUFFIX}""${SRC_TAG}"'."))) | .[] .ResourceRecords | .[] .Value')
[ -z "${SRC_PUBLISH_IP}" ] && exit 1

DEST_AUTHOR_IP=$(aws route53 list-resource-record-sets --hosted-zone-id "${ZONE_ID}" | jq -c -r '.ResourceRecordSets | map(select(.Name | contains ("aemauthor'"${ENV_SUFFIX}""${DEST_TAG}"'."))) | .[] .ResourceRecords | .[] .Value')
[ -z "${DEST_AUTHOR_IP}" ] && exit 1

DEST_PUBLISH_IP=$(aws route53 list-resource-record-sets --hosted-zone-id "${ZONE_ID}" | jq -c -r '.ResourceRecordSets | map(select(.Name | contains ("aempublish-1'"${ENV_SUFFIX}""${DEST_TAG}"'."))) | .[] .ResourceRecords | .[] .Value')
[ -z "${DEST_PUBLISH_IP}" ] && exit 1

### Fetch Instance ID from Private IP Address
SRC_AUTHOR_INSTANCE_ID=$(aws ec2 describe-instances --filters Name=private-ip-address,Values="${SRC_AUTHOR_IP}" --query 'Reservations[*].Instances[*].{Instance:InstanceId}' --output text)
SRC_PUBLISH_INSTANCE_ID=$(aws ec2 describe-instances --filters Name=private-ip-address,Values="${SRC_PUBLISH_IP}" --query 'Reservations[*].Instances[*].{Instance:InstanceId}' --output text)
DEST_AUTHOR_INSTANCE_ID=$(aws ec2 describe-instances --filters Name=private-ip-address,Values="${DEST_AUTHOR_IP}" --query 'Reservations[*].Instances[*].{Instance:InstanceId}' --output text)
DEST_PUBLISH_INSTANCE_ID=$(aws ec2 describe-instances --filters Name=private-ip-address,Values="${DEST_PUBLISH_IP}" --query 'Reservations[*].Instances[*].{Instance:InstanceId}' --output text)

echo "${SRC_AUTHOR_INSTANCE_ID}" > instance/src_author_instance_id
echo "${SRC_PUBLISH_INSTANCE_ID}" > instance/src_publish_instance_id
echo "${DEST_AUTHOR_INSTANCE_ID}" > instance/dest_author_instance_id
echo "${DEST_PUBLISH_INSTANCE_ID}" > instance/dest_publish_instance_id

echo "SOURCE AEM AUTHOR INSTANCE ID is ${SRC_AUTHOR_INSTANCE_ID} (${SRC_AUTHOR_IP})"
echo "SOURCE AEM PUBLISH INSTANCE ID is ${SRC_PUBLISH_INSTANCE_ID} (${SRC_PUBLISH_IP})"
echo "DESTINATION AEM AUTHOR INSTANCE ID is ${DEST_AUTHOR_INSTANCE_ID} (${DEST_AUTHOR_IP})"
echo "DESTINATION AEM PUBLISH INSTANCE ID is ${DEST_PUBLISH_INSTANCE_ID} (${DEST_PUBLISH_IP})"

### Save Source, Destination Author and Publish Private IP for Volume mount purpose
echo "${SRC_AUTHOR_IP}" > instance/src_author_private_ip
echo "${SRC_PUBLISH_IP}" > instance/src_publish_private_ip
echo "${DEST_AUTHOR_IP}" > instance/dest_author_private_ip
echo "${DEST_PUBLISH_IP}" > instance/dest_publish_private_ip

echo "${SRC_TAG}" > instance/src_tag
echo "${ENVIRONMENT}" > instance/env_name

printf "\nFETCHING KEYPAIR FROM SECRETS...\n"
KEYPAIR=$(aws secretsmanager get-secret-value --secret-id "${KEYPAIR_KEY}" | jq -r '.SecretString')
[ -z "${KEYPAIR}" ] && echo "Could not retrieve KEYPAIR" && exit 1
echo "${KEYPAIR}" > key/keypair
echo "KEYPAIR IMPORTED"

printf "\nFETCHING AEM PASSWORD...\n"
AEM_PASSWORD=$(aws secretsmanager get-secret-value --secret-id "${SECRET_KEY}" | jq -r '.SecretString' | jq -r .aem_password)
[ -z "${AEM_PASSWORD}" ] && echo "Could not retrieve AEM PASSWORD" && exit 1
echo "${AEM_PASSWORD}" > key/aempasswd