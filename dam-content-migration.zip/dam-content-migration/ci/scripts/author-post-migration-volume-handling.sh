#!/bin/sh

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID}"
export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY}"
export AWS_DEFAULT_REGION="${REGION}"

SRC_AUTHOR_INSTANCE_ID=$(cat instance/src_author_instance_id)
DEST_AUTHOR_INSTANCE_ID=$(cat instance/dest_author_instance_id)
SRC_AUTHOR_VOLUME_ID=$(cat volume/src_author_volume_id)

### Detach volume from the Destination AEM author instance
echo "DETACHING VOLUME ${SRC_AUTHOR_VOLUME_ID} FROM DESTINATION AUTHOR INSTANCE ${DEST_AUTHOR_INSTANCE_ID}..."
aws ec2 detach-volume --volume-id "${SRC_AUTHOR_VOLUME_ID}" --instance-id "${DEST_AUTHOR_INSTANCE_ID}"
sleep 30s
echo "VOLUME DETACHED"
echo "---------------"
### Attach volume to the Source AEM author instance
echo "ATTACHING VOLUME ${SRC_AUTHOR_VOLUME_ID} TO SOURCE AUTHOR INSTANCE ${SRC_AUTHOR_INSTANCE_ID}..."
aws ec2 attach-volume --volume-id "${SRC_AUTHOR_VOLUME_ID}" --instance-id "${SRC_AUTHOR_INSTANCE_ID}" --device /dev/sdh
sleep 30s
echo "VOLUME ATTACHED"