#!/usr/bin/env bash

SSH_TUNNEL_PORT="6666"

eval "$(ssh-agent -s)"
chmod 400 key/keypair

SRC_AUTHOR_INSTANCE_ID=$(cat instance/src_author_instance_id)
SRC_AUTHOR_IP=$(cat instance/src_author_private_ip)

cd certs
ssh-add atb_service_user
ssh-add -l
ssh -o ProxyCommand='ssh -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SSH_TUNNEL_PORT":"$SRC_AUTHOR_IP":22 &
cd ..
sleep 5
### Opening tunnel to Source AEM Author
printf "\nTUNNEL OPEN TO DESTINATION AUTHOR at %s\n" "${SRC_AUTHOR_IP}"
### Mounting volume to the source author instance
echo "MOUNTING VOLUME /dev/nvme1n1 BACK TO SOURCE AUTHOR INSTANCE ${SRC_AUTHOR_INSTANCE_ID}..."
ssh -q -o IPQoS=throughput -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT} ec2-user@localhost 'sudo mount /dev/nvme1n1 /apps/adobe && df -hT /adobe'
sleep 5
printf "VOLUME MOUNTED\n\n"
### Starting AEM Author instance
ssh -q -o IPQoS=throughput -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT} ec2-user@localhost 'sudo /etc/init.d/cq64-author start'
sleep 5
printf "SOURCE AEM AUTHOR INSTANCE STARTED\n\n"
### Start Filebeat service
ssh -q -o IPQoS=throughput -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT} ec2-user@localhost 'sudo service filebeat start'
sleep 5
printf "FILEBEAT SERVICE STARTED"
kill %1