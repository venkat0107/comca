#!/bin/sh

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID}"
export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY}"
export AWS_DEFAULT_REGION="${REGION}"

AEM_DEVICE_NAME="/dev/sdh"
TODAY=$(date +'%d-%m-%Y-%H:%M')

SRC_TAG=$(cat instance/src_tag)
ENVIRONMENT=$(cat instance/env_name)

SRC_AUTHOR_INSTANCE_ID=$(cat instance/src_author_instance_id)
echo "SOURCE AEM AUTHOR INSTANCE ID is ${SRC_AUTHOR_INSTANCE_ID}"

### Fetch Volume ID of the AEM instances
SRC_AUTHOR_VOL_ID=$(aws ec2 describe-volumes --filters Name=attachment.instance-id,Values="${SRC_AUTHOR_INSTANCE_ID}" Name=attachment.device,Values="${AEM_DEVICE_NAME}" --query Volumes[].VolumeId --output text)
echo "SOURCE AEM AUTHOR VOLUME is ${SRC_AUTHOR_VOL_ID}"
echo "${SRC_AUTHOR_VOL_ID}" > volume/src_author_volume_id

### Use a description for Snapshot
AUTHOR_SNAPSHOT_DESC="aem-author-${AEM_DEVICE_NAME}-${TODAY}"

### Execute Snapshot
AUTHOR_SNAPSHOT_ID=$(aws ec2 create-snapshot --output=text --description "${AUTHOR_SNAPSHOT_DESC}" --volume-id "${SRC_AUTHOR_VOL_ID}" --query SnapshotId)

### Add tags to the snapshot
aws ec2 create-tags --resource "${AUTHOR_SNAPSHOT_ID}" --tags Key=CreatedByFor,Value=BackupForAEMContentMigration Key=Application,Value=AEM Key=Name,Value=aem-"${ENVIRONMENT}"-author"${SRC_TAG}" Key=Owner,Value=Martech

### Wait for Snapshot Completion
AUTHOR_SNAPSHOTPROGRESS=$(aws ec2 describe-snapshots --snapshot-ids "${AUTHOR_SNAPSHOT_ID}" --query "Snapshots[*].Progress" --output text)

echo "CREATING SNAPSHOT FOR SOURCE AEM AUTHOR..."
while [ "${AUTHOR_SNAPSHOTPROGRESS}" != "100%" ]
do
  sleep 15
  echo "PROGRESS is ${AUTHOR_SNAPSHOTPROGRESS}"
  AUTHOR_SNAPSHOTPROGRESS=$(aws ec2 describe-snapshots --snapshot-ids "${AUTHOR_SNAPSHOT_ID}" --query "Snapshots[*].Progress" --output text)
done
echo "SOURCE AEM AUTHOR SNAPSHOT is ${AUTHOR_SNAPSHOT_ID}"
sleep 30

echo "${AUTHOR_SNAPSHOT_ID}" > snapshot/author_snapshot_id