#!/usr/bin/env bash

set -e
trap 'catch $? $LINENO' EXIT
catch() {
  echo "catching!"
  if [ "$1" != "0" ]; then
    # error handling goes here
    echo "Error $1 occurred on $2"
  fi
}

SSH_TUNNEL_PORT_1="4444"
SSH_TUNNEL_PORT_2="4454"

eval "$(ssh-agent -s)"
chmod 400 key/keypair

SRC_AUTHOR_INSTANCE_ID=$(cat instance/src_author_instance_id)
SRC_AUTHOR_IP=$(cat instance/src_author_private_ip)
echo "SOURCE AEM AUTHOR IP is ${SRC_AUTHOR_IP}"

SRC_AUTHOR_VOL_ID=$(cat volume/src_author_volume_id)
echo "SOURCE AEM AUTHOR VOLUME is ${SRC_AUTHOR_VOL_ID}"

DEST_AUTHOR_IP=$(cat instance/dest_author_private_ip)

cd certs
ssh-add atb_service_user
ssh-add -l
ssh -o ProxyCommand='ssh -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SSH_TUNNEL_PORT_1":"$SRC_AUTHOR_IP":22 &
cd ..
sleep 5
### Opening tunnel to Source Author
printf "\nTUNNEL OPEN TO SOURCE AUTHOR at %s\n" "${SRC_AUTHOR_IP}"
echo "UNMOUNTING AEM VOLUME ${SRC_AUTHOR_VOL_ID}..."
### Unmounting the AEM volume from source AEM Author instance
ssh -q -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT_1} ec2-user@localhost "sudo umount /dev/nvme1n1"
sleep 5
echo "AEM VOLUME ${SRC_AUTHOR_VOL_ID} (/dev/nvme1n1) UNMOUNTED FROM SOURCE AEM AUTHOR INSTANCE ${SRC_AUTHOR_INSTANCE_ID}"
kill %1

cd certs
ssh -o ProxyCommand='ssh -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no -qx svcAutobahn@jump.autobahn.comcast.com -W $BASTION_HOST:22' -N -o IPQoS=throughput -o ServerAliveInterval=60 -o StrictHostKeyChecking=no "$BASTION_USER"@"$BASTION_HOST" -L "$SSH_TUNNEL_PORT_2":"$DEST_AUTHOR_IP":22 &
cd ..
sleep 5
printf "\nTUNNEL OPEN TO DESTINATION AUTHOR at %s\n" "${DEST_AUTHOR_IP}"
### Download CRX2Oak content migration script from S3
printf "DOWNLOADING CONTENT MIGRATION SCRIPT FROM S3..."
ssh -q -o IPQoS=throughput -o ServerAliveInterval=60 -o "StrictHostKeyChecking no" -i key/keypair -t -p ${SSH_TUNNEL_PORT_2} ec2-user@localhost 'sudo aws s3 cp s3://'"dam-aem-files${ENV_SUFFIX}"'/crx2oak-content-migration.sh /apps/adobe/aem6.4/ && sudo chmod +x /apps/adobe/aem6.4/crx2oak-content-migration.sh'
kill %1