﻿#!/bin/bash

#==================================================================================
# Title          :  CR2OAK Content Migration
# Description    :  Content Migration using CRX2OAK Tool between two AEM instances
# Author         :  Vishnuvardhan Krishnan (vkrish214)
# Email          :  vishnuvardhan_krishnan@comcast.com
#==================================================================================

### Set variables
TODAY=$(date +'%d-%m-%Y-%H-%M')
CR2OAK_HOME="/apps/adobe/aem6.4"

### Log File
LOGFILE="$CR2OAK_HOME/crx2oak-migration-${TODAY}.log"

### Fetch AWS Region
REGION=$(wget -q -O- http://169.254.169.254/latest/meta-data/placement/availability-zone | sed -e 's/\([1-9]\).$/\1/g')
echo "Region is ${REGION}" >> "${LOGFILE}"

### Fetch EC2 Instance ID
INSTANCE_ID=$(wget -q -O- http://169.254.169.254/latest/meta-data/instance-id)
INSTANCE_NAME=$(aws ec2 describe-tags --region "${REGION}" --filters "Name=resource-id,Values=${INSTANCE_ID}" "Name=key,Values=Name" --output text | cut -f5)
echo -e "EC2 Instance Mame is ${INSTANCE_NAME}\n" | sudo tee -a "${LOGFILE}"

### Mounting Source Volume
echo -e "Mounting Source File system /dev/nvme3n1 onto Destination..." | sudo tee -a "${LOGFILE}"
sudo mount /dev/nvme3n1 /vol01/adobe | sudo tee -a "${LOGFILE}"
echo -e "Volume mounted\n" | sudo tee -a "${LOGFILE}"

df -hT /adobe /vol01/adobe | sudo tee -a "${LOGFILE}"

### Stopping Filebeat service
echo -e "\nStopping Filebeat service..." | sudo tee -a "${LOGFILE}"
sudo service filebeat stop | sudo tee -a "${LOGFILE}"

### AEM Instance
# removed the path /content/assets from the migration - US1751958
# added the path /etc/dam-asc-tools/metadata-field-list for including "Copy metadata"
# added the path /var/dam/share for including "Link Share Reports"
if [[ ${INSTANCE_NAME} = *"author"* ]];
then
  DEST_CQ_HOME="/apps/adobe/aem6.4/author"
  SRC_CQ_HOME="/vol01/adobe/aem6.4/author"
  INSTANCE_TYPE="author"
  INCLUDE_PATHS="/content/en,\
/content/dam/assets,/var/audit,/var/workflow/instances,/var/acs-commons/reports,/conf/dam-asc-custom,/conf/global,/home/users/saml-users,/var/audit/share,\
/var/workflow/models/Asset-Approved-Move-to-Publish,/var/workflow/models/Asset-Approved-Move-to-Reference,\
/var/workflow/models/Asset-Ingestion-Workflow,/var/workflow/models/Asset-Rejected-Move-to-Draft,\
/var/workflow/models/Asset-Move-to-Archive,/var/workflow/models/Asset-Move-to-Publish,/var/workflow/models/dam-xmp-writeback,\
/var/workflow/models/Asset-Move-to-Reference,/var/workflow/models/Custom_DAM_Update_Asset,/var/workflow/models/dam/update_asset,/etc/packages/dam-martech-metadata,/etc/dam-asc-tools/metadata-field-list"
elif [[ ${INSTANCE_NAME} = *"publish"* ]];
then
  DEST_CQ_HOME="/apps/adobe/aem6.4/publish"
  SRC_CQ_HOME="/vol01/adobe/aem6.4/publish"
  INSTANCE_TYPE="publish"
  INCLUDE_PATHS="/content/en,/content/dam/assets,/var/audit,/var/acs-commons/reports,/conf/dam-asc-custom,/conf/global,/home/users/saml-users,/var/audit/share"
fi

### Heap Memory allocation
xmx=`grep "MemTotal" /proc/meminfo | grep -o "[0-9]*" | awk '{print int($1 / 1024 / 1024) - 5}'`
### Print Heap Memory
echo -e "\nHeap Memory allocated for Migration Process is ${xmx}GB" | sudo tee -a "${LOGFILE}"

### Source & Destination DataStore
SRC_DATASTORE="${SRC_CQ_HOME}/crx-quickstart/repository/repository/datastore"
SRC_S3CONFIG="${SRC_CQ_HOME}/crx-quickstart/install/org.apache.jackrabbit.oak.plugins.blob.datastore.S3DataStore.config"
DEST_DATASTORE="${DEST_CQ_HOME}/crx-quickstart/repository/repository/datastore"
DEST_S3CONFIG="${DEST_CQ_HOME}/crx-quickstart/install/org.apache.jackrabbit.oak.plugins.blob.datastore.S3DataStore.config"
SRC_REPO="${SRC_CQ_HOME}/crx-quickstart/repository"
DEST_REPO="${DEST_CQ_HOME}/crx-quickstart/repository"

### Print Filesystem disk usage
echo "Disk usage Before Migration..." | sudo tee -a "${LOGFILE}"
df -hT /adobe | sudo tee -a "${LOGFILE}"

echo -e "\nSTART OF MIGRATION : $(date +%H:%M:%S) UTC" | sudo tee -a "${LOGFILE}"
echo "=================================" >> "${LOGFILE}"

### CRX2OAK Process initiation
sudo java -Xmx${xmx}g -Dlogback.configurationFile=/apps/adobe/aem6.4/logback-crx2oak-migration.xml -XX:+HeapDumpOnOutOfMemoryError -jar /apps/adobe/aem6.4/crx2oak-*.jar \
--copy-binaries --copy-versions=true \
--copy-orphaned-versions=true \
--src-s3datastore=${SRC_DATASTORE} \
--src-s3config=${SRC_S3CONFIG} \
--s3datastore=${DEST_DATASTORE} \
--s3config=${DEST_S3CONFIG} \
--include-paths=${INCLUDE_PATHS} \
${SRC_REPO} \
${DEST_REPO} >> "${LOGFILE}" &

sleep 5m

## Check Process Completion
tail -f "${LOGFILE}" | while read -r COMPLETION_CHECK
do
    [[ "${COMPLETION_CHECK}" == *"c.a.g.crx2oak.engine.MigrationRunner - migration completed"* ]] &&  pkill -P $$ tail
done

sleep 60

#### Find and Kill crx2oak Process
pgrep -f logback-crx2oak-migration.xml | sudo xargs kill

echo "=================================" | sudo tee -a "${LOGFILE}"
echo -e "END OF MIGRATION   : $(date +%H:%M:%S) UTC\n" | sudo tee -a "${LOGFILE}"

### Assign AEM user permissions to AEM Home folder
chown -R aemadmin:aemadmin "${DEST_CQ_HOME}"
chown -R aemadmin:aemadmin "${SRC_CQ_HOME}"

### Print Filesystem disk usage
echo -e "Disk usage After Migration..." | sudo tee -a "${LOGFILE}"
df -hT /adobe | sudo tee -a "${LOGFILE}"

### Starting AEM Instance
echo -e "\nStarting AEM ${INSTANCE_TYPE^} Instance..." | sudo tee -a "${LOGFILE}"
sudo /etc/init.d/cq64-${INSTANCE_TYPE} start | sudo tee -a "${LOGFILE}"

### Starting Filebeat service
echo -e "\nStarting Filebeat service..." | sudo tee -a "${LOGFILE}"
sudo service filebeat start | sudo tee -a "${LOGFILE}"

### Unmount volume
echo -e "\nUnmounting File system /vol01/adobe from destination..." | sudo tee -a "${LOGFILE}"
sudo umount /vol01/adobe | sudo tee -a "${LOGFILE}"
echo -e "Volume unmounted\n" | sudo tee -a "${LOGFILE}"
